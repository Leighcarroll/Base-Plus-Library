
  # Training Guide Interface

  This is a code bundle for Training Guide Interface. The original project is available at https://www.figma.com/design/WNwyrCV9x1sh4iAAxZbxci/Training-Guide-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  