import { TableOfContents } from './components/TableOfContents';
import { TrainingSection } from './components/TrainingSection';
import { ResourcesSection } from './components/ResourcesSection';

export default function App() {
  const sections = [
    { id: 'overview', title: 'Übersicht' },
    { id: 'content-elements-intro', title: 'Einführung in Content Elements' },
    { id: 'content-elements-structure', title: 'Content Elements - Struktur' },
    { id: 'content-elements-types', title: 'Content Elements - Typen' },
    { id: 'content-elements-notes', title: 'Content Elements - Zusätzliche Hinweise' },
    { id: 'edit-text', title: 'Content Elements - Bearbeiten - Text' },
    { id: 'edit-rubriken', title: 'Content Elements - Bearbeiten - Rubriken' },
    { id: 'easy-design-overview', title: 'Easy Design Übersicht' },
    { id: 'easy-design-header-footer', title: 'Easy Design Kopf-/Fußzeile' },
    { id: 'contact-designer', title: 'Wann Sie Ihren Designer kontaktieren sollten' },
    { id: 'resources', title: 'Ressourcen' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-gray-900">Base Plus Schulungsleitfaden</h1>
          <p className="text-gray-600 mt-2">Ihr Shop-Update-Leitfaden</p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <aside className="lg:col-span-1">
            <TableOfContents sections={sections} />
          </aside>

          <main className="lg:col-span-3 space-y-12">
            {/* Overview Section */}
            <section id="overview" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Übersicht</h2>
              <h3 className="text-gray-900 mb-3">Was ist neu in Ihrem Shop mit Base Plus</h3>
              <p className="text-gray-700 mb-4">
                Wir haben nun das Base Plus Theme in Ihren Shop importiert. Sie werden jetzt zwei Hauptergänzungen 
                in Ihrem Shop bemerken: <strong>Easy Design</strong> + <strong>Content Elements</strong>.
              </p>
              <p className="text-gray-700 mb-4">
                <strong>Easy Design</strong> ist ein zentralisiertes Gestaltungssystem, das die bisherigen Design-Tools ersetzt, 
                wodurch es stabiler und einfacher wird, das Erscheinungsbild Ihres Shops anzupassen, ohne die Funktionalität zu beeinträchtigen.
              </p>
              <p className="text-gray-700 mb-4">
                <strong>Content Elements</strong> ist eine neue intuitive Methode zum Hinzufügen und Verwalten von Inhalten auf Ihren Seiten. 
                Anstatt mit HTML-Code zu arbeiten, können Sie jetzt Drag-and-Drop-Blöcke verwenden, um Ihre Inhalte zu organisieren.
              </p>
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <p className="text-gray-700">
                  <strong>Was ist Base Plus?</strong> Base Plus ist eine erweiterte Version Ihres Shop-Themes mit 
                  verbessertem Content-Management und Design-Funktionen.
                </p>
              </div>
            </section>

            {/* Content Elements Introduction */}
            <section id="content-elements-intro" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Einführung in Content Elements</h2>
              <p className="text-gray-700 mb-4">
                Content Elements sind ein guter Ausgangspunkt, da Sie wahrscheinlich den Inhalt Ihrer Website am häufigsten ändern werden. Die regelmäßige Aktualisierung des Inhalts Ihrer Website hilft Kunden, genaue und aktuelle Informationen zu finden, und lässt Ihren Shop aktiv und vertrauenswürdig erscheinen. Es verbessert auch Ihre Sichtbarkeit in Suchmaschinen und erleichtert es neuen Kunden, Ihr Geschäft zu entdecken.
              </p>
              <p className="text-gray-700 mb-4">
                Früher haben Sie, um Inhalte zu Seiten in Base hinzuzufügen, Datenblattansicht → eine Seite auswählen → Allgemeine → Text aufgerufen und alles als HTML eingegeben.
              </p>
              <p className="text-gray-700 mb-4">
                Jetzt werden Sie eine neue Schaltfläche namens Content Elements (manchmal "Inhaltliche Elemente") bemerken. Diese ist auf jeder "Seite/Kategorie"-Seite in Ihrem Shop sichtbar. Dieser Tab ist jetzt der zentrale Ort zum Hinzufügen von Inhalten zu Ihrem Shop.
              </p>
              <p className="text-gray-700 mb-4">
                Jeder "Block" erscheint in einer Liste, die Sie einfach verwalten können. Sie können per Drag-and-Drop neu anordnen, die Sichtbarkeit umschalten, löschen, kopieren, auf andere Seiten duplizieren und mit der Bearbeiten-Schaltfläche bearbeiten.
              </p>
              <div className="mt-6">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/bx7DcGv4BW4"
                    title="Einführung in Content Elements"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
              </div>
            </section>

            {/* Content Elements Structure */}
            <section id="content-elements-structure" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Content Elements - Struktur</h2>
              <p className="text-gray-700 mb-4">
                Um ein neues Content Element zu erstellen, müssen Sie einen Namen eingeben, einen Typ aus den verfügbaren Optionen auswählen und speichern. Neue Content Elements werden standardmäßig auf nicht-sichtbar gesetzt.
              </p>
              <p className="text-gray-700 mb-4">
                Es stehen mehrere Elementtypen zur Verfügung, jeder mit unterschiedlichen Verhaltensweisen und Funktionen. Jeder Typ kann über seine Einstellungen (klicken Sie auf Bearbeiten, um die Einstellungen zu sehen) an Ihre spezifischen Inhaltsbedürfnisse angepasst werden.
              </p>
              <div className="mt-6">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/czzZ0gnAHxk"
                    title="Content Elements Struktur"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
              </div>
            </section>

            {/* Content Elements Types */}
            <section id="content-elements-types" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Content Elements - Typen</h2>
              <p className="text-gray-700 mb-6">
                Es stehen mehrere Arten von Content Elements zur Verfügung, jede ist automatisch responsive für verschiedene Bildschirmgrößen.
              </p>
              
              <div className="space-y-4 mb-6">
                <div className="border-l-4 border-blue-500 pl-4">
                  <h3 className="text-gray-900 mb-2">Produktliste</h3>
                  <p className="text-gray-700">Fügen Sie Produktkarten hinzu, die in einer vertikalen Liste angezeigt werden. Die Standardansicht zeigt 4 Produkte pro Zeile, alle hinzugefügten Produkte sind sichtbar.</p>
                </div>
                
                <div className="border-l-4 border-green-500 pl-4">
                  <h3 className="text-gray-900 mb-2">Produkt-Slider</h3>
                  <p className="text-gray-700">Horizontaler animierter Slider, standardmäßig werden 4 Produktkarten gleichzeitig angezeigt.</p>
                </div>
                
                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="text-gray-900 mb-2">Text</h3>
                  <p className="text-gray-700">Vollständig anpassbarer Textbereich mit Video-/Fotoeinbettung, Verlinkung und HTML-Bearbeitung.</p>
                </div>
                
                <div className="border-l-4 border-orange-500 pl-4">
                  <h3 className="text-gray-900 mb-2">Foto-Element</h3>
                  <p className="text-gray-700">Einzelnes Bildelement.</p>
                </div>
                
                <div className="border-l-4 border-pink-500 pl-4">
                  <h3 className="text-gray-900 mb-2">Foto-Slider</h3>
                  <p className="text-gray-700">Mehrere Bilder in einem Slider-Format.</p>
                </div>
                
                <div className="border-l-4 border-indigo-500 pl-4">
                  <h3 className="text-gray-900 mb-2">Rubriken</h3>
                  <p className="text-gray-700">Erstellen Sie Spalten in einer einzelnen Zeile, die sich an die Bildschirmgröße anpassen. Jede Spalte kann Text, Produktkarten oder Bilder enthalten.</p>
                </div>
              </div>
            </section>

            {/* Content Elements Extra Notes */}
            <section id="content-elements-notes" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Content Elements - Zusätzliche Hinweise</h2>
              <p className="text-gray-700 mb-4">
                Automatisch konvertierte Elemente sind responsive und Drag-and-Drop-fähig, was sie für verschiedene 
                Bildschirmgrößen einfach zu handhaben macht. Diese Content Elements werden aus dem ursprünglichen Inhalt erstellt, den Sie zu jeder Seite hinzugefügt haben, wenn Ihr Shop auf das Base Plus Theme aktualisiert wird.
              </p>
              <p className="text-gray-700 mb-4">
                Sie heißen normalerweise
              </p>
              <ul className="space-y-2 text-gray-700 ml-6 mb-4">
                <li className="flex gap-2">
                  <span className="flex-shrink-0">•</span>
                  <span>Erweiterte Beschreibung</span>
                </li>
                <li className="flex gap-2">
                  <span className="flex-shrink-0">•</span>
                  <span>Zugewiesene Produkte</span>
                </li>
                <li className="flex gap-2">
                  <span className="flex-shrink-0">•</span>
                  <span>SubPage</span>
                </li>
              </ul>
              <div className="bg-blue-50 rounded-lg p-6">
                <p className="text-gray-700">
                  <strong>Tipp:</strong> Wenn Ihnen die automatische Formatierung konvertierter Elemente nicht gefällt, können Sie 
                  den Inhalt in neu erstellte Content Elements kopieren und einfügen, um mehr Kontrolle über das Layout 
                  und die Gestaltung zu haben.
                </p>
              </div>
              <div className="mt-6">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/SPLXxzsYn50"
                    title="Content Elements Zusätzliche Hinweise"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
              </div>
            </section>

            {/* How to Edit - Text */}
            <section id="edit-text" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Content Elements - Bearbeiten - Text</h2>
              <p className="text-gray-700 mb-6">
                Text-Content Elements haben mehrere Einstellungs-Tabs, die Ihnen volle Kontrolle über Ihre Inhalte geben:
              </p>

              <div className="space-y-6">
                <div>
                  <h3 className="text-gray-900 mb-3">Text-Tab</h3>
                  <p className="text-gray-700 mb-2">
                    Der Hauptbearbeitungsbereich, in dem Sie Ihre Inhalte hinzufügen und formatieren können:
                  </p>
                  <ul className="space-y-2 text-gray-700 ml-6">
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Rich-Text-Editor mit Formatierungsoptionen</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Video-Einbettungsfunktionen</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>HTML-Modus für fortgeschrittene Benutzer</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Sprach-Tabs für mehrsprachige Unterstützung</span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Stil-Tab</h3>
                  <p className="text-gray-700">
                    Kontrollieren Sie das visuelle Erscheinungsbild Ihres Textelements einschließlich Abstand, Breite und Hintergrundfarbe.
                  </p>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Einstellungen-Tab</h3>
                  <p className="text-gray-700">
                    Wechseln Sie zwischen WYSIWYG (What You See Is What You Get) Modus und strukturiertem Formatierungsmodus.
                  </p>
                </div>
              </div>

              <div className="mt-6">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/hy1nahfEgH0"
                    title="Content Elements Bearbeiten Text"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
              </div>
            </section>

            {/* How to Edit - Rubriken */}
            <section id="edit-rubriken" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Content Elements - Bearbeiten - Rubriken</h2>
              <p className="text-gray-700 mb-6">
                Rubriken ermöglichen es Ihnen, 3 responsive Elemente zu erstellen, die Text, Bilder oder Produkte enthalten können. Die Produkt-, Bild- und Texteinstellungen für andere Content Elements sind identisch oder ähnlich.
              </p>

              <div className="space-y-6">
                <div>
                  <h3 className="text-gray-900 mb-3">Container</h3>
                  <p className="text-gray-700">
                    Ordnen Sie Elemente neu an, schalten Sie die Sichtbarkeit um und fügen Sie Beschriftungstext oder einen Titel zu Ihrer Zeile hinzu.
                  </p>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Text</h3>
                  <p className="text-gray-700">
                    Diese Einstellungen sind die gleichen wie die Texteinstellungen im vorherigen Abschnitt.
                  </p>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Bild-Tab</h3>
                  <ul className="space-y-2 text-gray-700 ml-6">
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Laden Sie verschiedene Bilder für Desktop- und Mobilansichten hoch</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Fügen Sie Metadaten für SEO-Zwecke hinzu</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Aktivieren Sie Lazy Loading (empfohlen für SEO, außer für Header-Bilder)</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Laden Sie verschiedene Bilder oder Metadaten für verschiedene Sprachansichten hoch - beachten Sie, dass ohne zusätzlichen Inhalt automatisch die Hauptsprache verwendet wird.</span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Stil</h3>
                  <p className="text-gray-700">
                    Kontrollieren Sie Bildhöhe und Abstand zwischen Elementen.
                  </p>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Produkte</h3>
                  <p className="text-gray-700">
                    Suchen und wählen Sie Produkte zur Anzeige aus. Die Einstellungen sind ähnlich der Produkt-Slider-Konfiguration.
                  </p>
                </div>
              </div>

              <div className="mt-6">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/v2w8EwRTvUI"
                    title="Content Elements Bearbeiten Rubriken"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
              </div>
            </section>

            {/* Easy Design Overview */}
            <section id="easy-design-overview" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Easy Design Übersicht</h2>
              <p className="text-gray-700 mb-4">
                Easy Design ersetzt die bisherigen Tools Erweiterte Gestaltung und Schnellgestaltung. Es bietet 
                ein stabileres System, das schwerer zu beschädigen ist, mit einem zentralen Ort für alle Ihre Gestaltungsbedürfnisse.
              </p>
              <p className="text-gray-700 mb-6">
                Diese neue Benutzeroberfläche gibt Ihnen bessere Kontrolle über das Erscheinungsbild Ihres Shops und sorgt gleichzeitig für Konsistenz 
                und verhindert häufige Designprobleme.
              </p>
            </section>

            {/* Easy Design Header/Footer */}
            <section id="easy-design-header-footer" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Easy Design Kopf-/Fußzeile</h2>

              <div className="space-y-6">
                <div>
                  <h3 className="text-gray-900 mb-3">Kopfzeile</h3>
                  <p className="text-gray-700">
                    Die Kopfzeile hat drei Ebenen und wird im Allgemeinen von Ihrem Designer konfiguriert. Seien Sie vorsichtig bei 
                    Änderungen, um die Konsistenz zu wahren.
                  </p>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Fußzeile</h3>
                  <p className="text-gray-700">
                    Enthält bearbeitbare Inhaltselemente. Es ist sicher, Text und Inhalt im Fußzeilenbereich zu ändern.
                  </p>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Sidebars</h3>
                  <p className="text-gray-700">
                    Werden in modernen Shop-Designs selten verwendet.
                  </p>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Produkt-Layout</h3>
                  <p className="text-gray-700">
                    Steuert die Anzahl der pro Zeile angezeigten Produkte und Cross-Selling-Text.
                  </p>
                </div>

                <div>
                  <h3 className="text-gray-900 mb-3">Theme</h3>
                  <p className="text-gray-700 mb-3">
                    Enthält viele Gestaltungsoptionen einschließlich Farben, Abstände und Typografie. Wichtige Bereiche umfassen:
                  </p>
                  <ul className="space-y-2 text-gray-700 ml-6">
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span><strong>Mitte:</strong> Globale Einstellungen für H1/H2/H3 Überschriftengrößen</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span><strong>ProduktKarte:</strong> Steuert Textgrößen auf Produktkarten</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <p className="text-gray-700">
                    <strong>Hinweis:</strong> Die Abschnitte Inhaltliche Elemente und Erweiterte Einstellungen sind nur für 
                    Designer bestimmt. Bitte kontaktieren Sie Ihren Designer, wenn in diesen Bereichen Änderungen erforderlich sind.
                  </p>
                </div>
              </div>

              <div className="mt-6">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/PSB9pzIBAH0"
                    title="Easy Design Kopf- und Fußzeile"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
              </div>
            </section>

            {/* When to Contact Your Designer */}
            <section id="contact-designer" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Wann Sie Ihren Designer kontaktieren sollten</h2>
              
              <p className="text-gray-700 mb-6">
                Während Sie die meisten Inhalte selbst verwalten können, erfordern bestimmte Änderungen technische Expertise. 
                Kontaktieren Sie Ihren Designer für Folgendes:
              </p>

              <div className="space-y-4 mb-6">
                <div className="flex gap-3 p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-900 flex-shrink-0">•</span>
                  <div>
                    <h3 className="text-gray-900 mb-1">Schriftartänderungen</h3>
                    <p className="text-gray-700">Benutzerdefinierte Schriftarten müssen in das System einprogrammiert werden</p>
                  </div>
                </div>

                <div className="flex gap-3 p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-900 flex-shrink-0">•</span>
                  <div>
                    <h3 className="text-gray-900 mb-1">Größere strukturelle Änderungen an Kopf-/Fußzeile</h3>
                    <p className="text-gray-700">Bedeutende Layout-Änderungen an Kopf- oder Fußzeilenbereichen</p>
                  </div>
                </div>

                <div className="flex gap-3 p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-900 flex-shrink-0">•</span>
                  <div>
                    <h3 className="text-gray-900 mb-1">Menüstil-Änderungen</h3>
                    <p className="text-gray-700">Wechsel zwischen kaskadierenden und Mega-Menü-Stilen</p>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="text-gray-900 mb-3">Designer-Kontaktinformationen</h3>
                <p className="text-gray-700 mb-2">
                  <strong>Bevorzugt:</strong> Behalten Sie einen Designer für Konsistenz während Ihres gesamten Projekts.
                </p>
                <p className="text-gray-700">
                  Kontaktieren Sie Ihren ursprünglichen Designer oder wenden Sie sich an: <strong>dcteam@epages.com</strong>
                </p>
              </div>
            </section>

            {/* Resources Section */}
            <section id="resources" className="bg-white rounded-lg shadow-sm p-8">
              <h2 className="text-gray-900 mb-4">Ressourcen</h2>
              <p className="text-gray-700 mb-6">
                Benötigen Sie zusätzliche Hilfe? Hier sind die verfügbaren Ressourcen, um Sie zu unterstützen.
              </p>

              <div className="space-y-6">
                <div className="border border-gray-200 rounded-lg p-6">
                  <h3 className="text-gray-900 mb-4">Für Base-Funktionen</h3>
                  <p className="text-gray-700 mb-4">
                    Kontaktieren Sie das Service Center für Hilfe bei Standard-Base-Funktionen:
                  </p>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>E-Mail-Support verfügbar</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Telefon-Support für dringende Probleme</span>
                    </li>
                  </ul>
                </div>

                <div className="border border-gray-200 rounded-lg p-6">
                  <h3 className="text-gray-900 mb-4">Für Feedback</h3>
                  <p className="text-gray-700 mb-4">
                    Teilen Sie Ihre Gedanken und Vorschläge:
                  </p>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Senden Sie E-Mail-Feedback über Ihre Erfahrungen</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">•</span>
                      <span>Nehmen Sie an der Diskussion in unserer Facebook-Community teil</span>
                    </li>
                  </ul>
                </div>
              </div>
            </section>
          </main>
        </div>
      </div>
    </div>
  );
}