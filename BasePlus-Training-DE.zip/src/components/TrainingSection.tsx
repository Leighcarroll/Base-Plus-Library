import { PlayCircle } from 'lucide-react';

interface TrainingSectionProps {
  id: string;
  title: string;
  description: string;
  instructions: string[];
  videoUrl: string;
}

export function TrainingSection({
  id,
  title,
  description,
  instructions,
  videoUrl
}: TrainingSectionProps) {
  return (
    <section id={id} className="bg-white rounded-lg shadow-sm p-8">
      <h2 className="text-gray-900 mb-4">{title}</h2>
      
      <p className="text-gray-700 mb-6">{description}</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Instructions */}
        <div>
          <h3 className="text-gray-900 mb-3">Instructions</h3>
          <ul className="space-y-3">
            {instructions.map((instruction, index) => (
              <li key={index} className="flex gap-3">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center">
                  {index + 1}
                </span>
                <span className="text-gray-700 pt-0.5">{instruction}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Video */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <PlayCircle className="w-5 h-5 text-gray-700" />
            <h3 className="text-gray-900">Video Tutorial</h3>
          </div>
          <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
            <iframe
              width="100%"
              height="100%"
              src={videoUrl}
              title={`${title} Tutorial Video`}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
