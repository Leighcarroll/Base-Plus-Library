import { Phone, Mail, MessageCircle, BookOpen } from 'lucide-react';

interface ResourcesSectionProps {
  id: string;
}

export function ResourcesSection({ id }: ResourcesSectionProps) {
  return (
    <section id={id} className="bg-white rounded-lg shadow-sm p-8">
      <h2 className="text-gray-900 mb-4">Resources</h2>
      <p className="text-gray-700 mb-6">
        Need additional help? Here are some resources to support you as you learn the new software.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Technical Support */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Phone className="w-5 h-5 text-blue-700" />
            </div>
            <h3 className="text-gray-900">Technical Support</h3>
          </div>
          <div className="space-y-2 text-gray-700">
            <p>Phone: 1-800-555-0123</p>
            <p>Available: Mon-Fri, 8am-6pm EST</p>
          </div>
        </div>

        {/* Email Support */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Mail className="w-5 h-5 text-green-700" />
            </div>
            <h3 className="text-gray-900">Email Support</h3>
          </div>
          <div className="space-y-2 text-gray-700">
            <p>support@example.com</p>
            <p>Response time: Within 24 hours</p>
          </div>
        </div>

        {/* Live Chat */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-purple-700" />
            </div>
            <h3 className="text-gray-900">Live Chat</h3>
          </div>
          <div className="space-y-2 text-gray-700">
            <p>Available in the app</p>
            <p>Click the chat icon in the bottom-right corner</p>
          </div>
        </div>

        {/* Documentation */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-orange-700" />
            </div>
            <h3 className="text-gray-900">Documentation</h3>
          </div>
          <div className="space-y-2 text-gray-700">
            <p>docs.example.com</p>
            <p>Comprehensive guides and tutorials</p>
          </div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <p className="text-gray-700">
          <strong>Training Sessions:</strong> Join our weekly live training sessions every Wednesday at 2pm EST. 
          Register at training.example.com
        </p>
      </div>
    </section>
  );
}
